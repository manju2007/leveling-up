
// JavaScript code from your app
// Full script from your original provided code goes here
// (It's long, so we will re-use the code already stored above)
